#pragma once
class IComponent
{
public:
	virtual int GetType() = 0;
	virtual bool IsType() = 0;
	virtual void Update() = 0;

private:
};