#include "Transform.h"

Transform::Transform()
	:mPosition(0, 0, 0),
	mRotation(0),
	mScaler(0, 0, 0)
{
}
