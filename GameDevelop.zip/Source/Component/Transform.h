#pragma once
#include <Eigen/core>
class Transform
{
public:
	Transform();

	Eigen::Vector3f mPosition;
	float mRotation;
	Eigen::Vector3f mScaler;
};