#pragma once
#include <string>
class Character
{
private:
	int ID;
	std::string CharacterName;
};