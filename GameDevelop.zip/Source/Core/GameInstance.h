#pragma once
class GameInstance
{
public:
	bool isExit() { return bIsExit; };
	int Start() { return 0; }
	int Exit() { return 0; }
private:
	bool bIsExit;
};

