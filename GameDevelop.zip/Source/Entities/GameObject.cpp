
#include "GameObject.h"
#include "../Managers/ResourceManager.h"
#include "../Renderer/SpriteRenderer.h"

#include "../Physics/HitInfo.h"

#include <Eigen/Core>
extern ResourceManager* g_pResourceManager;

GameObject::GameObject()
	:mObjectID(0),
	mInstanceID(0)
{
	mTransform = nullptr;
}

GameObject::~GameObject()
{
	delete mTransform;
}

void GameObject::OnRender()
{
}

void GameObject::OnKeyPressed()
{
}

void GameObject::OnCollide(HitInfo& hitInfo)
{
}

void GameObject::Update(float elasedTime)
{
}
