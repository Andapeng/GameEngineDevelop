#pragma once
#include <string>
#include "../Component/Transform.h"
class SpriteRenderer;
class HitInfo;

class GameObject
{
public:
	GameObject();
	~GameObject();
	virtual void OnRender();
	virtual void OnKeyPressed();
	virtual void OnCollide(HitInfo& hitInfo);

	virtual void Update(float elasedTime);

protected:
	Transform* mTransform;
private:
	int mObjectID;
	int mInstanceID;
	
};