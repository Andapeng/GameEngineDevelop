#include "Game.h"
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "../Managers/StateManager.h"
#include "../Managers/ResourceManager.h"
#include "../Managers/GraphicsManager.h"
#include "../Managers/FontManager.h"
#include "../Managers/InputManager.h"
#include "../Managers/PhysicsManager.h"

#include <GLAD/glad.h>
#include "../RHI/Shader.h"
#include "../RHI/Texture.h"
#include "../RHI/Character.h"

#include "../Renderer/SpriteRenderer.h"
#include "../Renderer/TextRenderer.h"

#include "../Entities/GameObject.h"
#include "../Entities/RenderableObject.h"
#include "../Entities/Player.h"

#include "Snake.h"
#include "Food.h"

#include <iostream>
#include "GlobalConfiguration.h"
StateManager* g_pStateManager;
ResourceManager* g_pResourceManager;
GraphicsManager* g_pGraphicsManager;
FontManager* g_pFontManager;
InputManager* g_pInputManager;
PhysicsManager* g_pPhysicsManager;

SpriteRenderer* spriteRenderer;
TextRenderer* textRenderer;

RenderableObject* Person;
RenderableObject* Background;
RenderableObject* DialogBox;

Player* player;
Snake* snake;
Food* food;

sf::Music MusicPlayer;

// ---
Game::Game()
	:mWindow(nullptr)
{
	
}

// ---public
int Game::Initialize()
{

	// Managers Initializing
	g_pStateManager = StateManager::Get();
	g_pResourceManager = ResourceManager::Get();
	g_pGraphicsManager = GraphicsManager::Get();
	g_pFontManager = FontManager::Get();
	g_pInputManager = InputManager::Get();
	g_pPhysicsManager = PhysicsManager::Get();

	g_pGraphicsManager->Initialize();
	g_pFontManager->Initialize();
	g_pInputManager->Initialize();
	g_pPhysicsManager->Initialize();
	
	// Pre Load Resource
	g_pResourceManager->LoadTexture("Assets/Textures/awesomeface.png", "face");
	g_pResourceManager->LoadTexture("Assets/Textures/dialogbox005.png", "dialogbox");
	g_pResourceManager->LoadTexture("Assets/Textures/Background2.jpg", "background");
	g_pResourceManager->LoadTexture("Assets/Textures/girl001.jpg", "character");
	g_pResourceManager->LoadTexture("Assets/Textures/Blank.png", "blank");
	g_pResourceManager->LoadShader("Assets/Shaders/texture.vertex", "Assets/Shaders/texture.fragment", "texture_shader");
	g_pResourceManager->LoadShader("Assets/Shaders/sprite.vertex", "Assets/Shaders/sprite.fragment", "sprite_shader");
	g_pResourceManager->LoadShader("Assets/Shaders/text.vertex", "Assets/Shaders/text.fragment", "text_shader");
	g_pFontManager->LoadFont("Assets/Fonts/simsun.ttc");

	Eigen::Matrix4f projection = Ortho(0.0f, DEFAULT_WIDTH, DEFAULT_HEIGHT, 0.0f, -1.0f, 1.0f);
	std::cout << "Projection Matrix: \n" << projection << std::endl;
	
	Eigen::Matrix4f projection1 = Ortho(0.0f, DEFAULT_WIDTH, DEFAULT_HEIGHT, 0.0f);

	// Set Shader Uniform
	g_pResourceManager->GetShader("sprite_shader").Use()->SetInt("texture1", 0);
	g_pResourceManager->GetShader("sprite_shader").SetMatrix4f("projection", projection);

	g_pResourceManager->GetShader("text_shader").Use()->SetInt("text", 0);
	g_pResourceManager->GetShader("text_shader").SetMatrix4f("projection", projection1);

	g_pResourceManager->GetShader("texture_shader").Use()->SetInt("texture1", 0);

	spriteRenderer = g_pGraphicsManager->GetSpriteRenderer();

	textRenderer = g_pGraphicsManager->GetTextRenderer();

	Person = new RenderableObject("character", 200, 100, 658, 548);
	Background = new RenderableObject("background", 0, 0, 800, 600);
	DialogBox = new RenderableObject("dialogbox", 50, 300, 700, 300);

	player = new Player("blank", 0, 0, 50, 50);

	snake = new Snake("blank", 0, 0, 50);
	food = new Food("blank");
	//MusicPlayer.openFromFile("Assets/Music/Start1.ogg");
	//MusicPlayer.play();
	return 0;
}

int Game::Tick()
{
	ProcessInput();	
	Render();

	return 0;
}

int Game::Release()
{
	delete food;
	delete snake;
	delete player;
	delete DialogBox;
	delete Background;
	delete Person;
	
	
	g_pFontManager->Release();
	g_pGraphicsManager->Release();
	g_pResourceManager->Release();
	g_pInputManager->Release();
	g_pPhysicsManager->Release();

	return 0;
}


// ---private

// handle event
void Game::ProcessInput()
{
	//player->OnKeyPressed();
	if (IsRunning())
	{
		snake->OnKeyPressed();
	}
}


void Game::Render()
{
	
	//spriteRenderer->RenderSprite(g_pResourceManager->GetTexture("awesomeface"), Eigen::Vector2f(400, 200), Eigen::Vector2f(100, 100), 0, Eigen::Vector3f(1.0f, 1.0f, 1.0f));
	//Background->OnRender(spriteRenderer);
	//Person->OnRender(spriteRenderer);
	//DialogBox->OnRender(spriteRenderer);

	//player->OnRender(spriteRenderer);
	if (!g_pStateManager->IsGameOver()) 
	{
		snake->OnRender();
		food->OnRender();
	}
	//textRenderer->RenderText(L"����һ��simple GAME", 80.0f, 360.0f, 1.0f, Eigen::Vector3f(0.0f, 0.0f, 0.0f));
}

void Game::Update(float elapsedTime)
{
	//player->Update(elapsedTime);
	if (IsRunning()) {
		snake->Update(elapsedTime);
		snake->eatFood(*food);
	}
}

void Game::DetectCollide()
{
	// snake for all wall
	//		checkcollide return hitInfo
	//		if hitInfo.isCollide is true
	//		snake.OnCollide and wall[n].OnCollide
	// snake and food
	//		checkcollide return hitInfo
	//		if hitInfo.isCollide is true
	//		snake.OnCollide and food.OnCollide
}


// change game state
bool Game::IsRunning()
{
	return g_pStateManager->IsGameRuning();
}

int Game::Stop()
{
	g_pStateManager->GameOver();
	return 0;
}

int Game::Pause()
{
	g_pStateManager->GamePause();
	return 0;
}

int Game::Start()
{
	g_pStateManager->GameStart();
	return 0;
}
