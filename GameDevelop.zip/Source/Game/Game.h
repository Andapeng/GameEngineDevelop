#pragma once
#include <SFML/Graphics.hpp>

class Game 
{

public:
	
	Game();
	int Initialize();
	int Tick();
	int Release();

	// manage event
	void ProcessInput();

	// manage render
	void Render();
	void Update(float elapsedTime);

	void DetectCollide();
	// manage game state
	bool IsRunning();
	int Stop();
	int Pause();
	int Start();
private:
	
};