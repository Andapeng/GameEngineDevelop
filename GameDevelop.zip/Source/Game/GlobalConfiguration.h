#pragma once
const int DEFAULT_WIDTH = 800;
const int DEFAULT_HEIGHT = 600;