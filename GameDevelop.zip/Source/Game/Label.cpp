#include "Label.h"
#include "../Renderer/SpriteRenderer.h"
Label::Label(const char* text, int xpos, int ypos, int size)
{
}

