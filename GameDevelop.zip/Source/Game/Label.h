#pragma once
#include "../Entities/RenderableObject.h"
#include <string>

class Label
{
public:
	Label(const char* text, int xpos, int ypos, int size);
private:
	std::string mText;
};