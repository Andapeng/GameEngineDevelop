#pragma once
class SnakeMap
{

private:
	int mWidth;
	int mHeight;
};