#pragma once
class Wall
{
private:

};