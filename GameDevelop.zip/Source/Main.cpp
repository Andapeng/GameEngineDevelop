﻿#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>

#include <iostream>
#include "Application.h"

using namespace std;

int main(int argc, char** args) {

    //_CrtSetBreakAlloc(1887);
    Application app;
    app.Initialize();
    app.Run();
    app.Release();

    _CrtDumpMemoryLeaks();
    return 0;
}