#include "AudioManager.h"
#include <AL/al.h>
#include "SFML/Audio.hpp"

sf::Music g_music;

int AudioManager::Initialize()
{
	mDevice = alcOpenDevice(nullptr);
	if (mDevice) {
		mContext = alcCreateContext(mDevice, nullptr);
		alcMakeContextCurrent(mContext);
	}	
	
	return 0;
}

void AudioManager::Release()
{
	alcMakeContextCurrent(NULL);
	alcDestroyContext(mContext);
	alcCloseDevice(mDevice);
	
}

void AudioManager::Tick()
{
}

int AudioManager::LoadMusicFromFile(std::string pathName)
{
	//loadWAVFile("test.wav", &format, &data, &size, &freq, &loop);
	g_music.openFromFile(pathName.data());
	return 0;
}

void AudioManager::Play()
{
	g_music.play();
}
