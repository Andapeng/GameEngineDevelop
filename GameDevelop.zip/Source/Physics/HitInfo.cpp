#include "HitInfo.h"

HitInfo::HitInfo()
	:mHit(false)
{
}
