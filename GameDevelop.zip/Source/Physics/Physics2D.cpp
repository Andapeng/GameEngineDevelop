#include "Physics2D.h"

int AABBIntersect(int x1, int y1, int x2, int y2)
{
	return 0;
}

int AABBIntersect(GameObject& obj1, GameObject& obj2)
{
	return 0;
}
