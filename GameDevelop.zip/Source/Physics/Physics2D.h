#pragma once
#include "../Entities/GameObject.h"


int AABBIntersect(GameObject& obj1, GameObject& obj2);