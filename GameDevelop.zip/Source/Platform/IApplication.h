#pragma once

class IApplication
{
public:

};