#pragma once
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
class SfmlApplication
{
private:
	sf::RenderWindow* Window;
};