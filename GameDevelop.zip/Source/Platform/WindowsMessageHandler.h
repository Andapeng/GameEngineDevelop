#pragma once
class WindowsMessageHandler
{
public:
	bool OnKeyDown();

	WindowsMessageHandler();

};