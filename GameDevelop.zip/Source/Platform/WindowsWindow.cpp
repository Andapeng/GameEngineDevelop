#include "WindowsWindow.h"

void WindowsWindow::Initialize()
{
}
