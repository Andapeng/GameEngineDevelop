#pragma once
class WindowsWindow
{
public:
	void Initialize();
};