#include "Renderer.h"
#include "../RHI/Shader.h"
#include "../RHI/Texture.h"
#include "../RHI/Character.h"	
#include "../Managers/StateManager.h"
#include "../Managers/ResourceManager.h"
#include "../Managers/GraphicsManager.h"
#include "../Managers/FontManager.h"
#include <cstdlib>
#include <iostream>

#include <GLAD/glad.h>

#include <ft2build.h>
#include <freetype/freetype.h>


void Renderer::Initialize()
{

}

void Renderer::TestRender()
{
	
}


void Renderer::Release()
{
	
}

void Renderer::ClearColor()
{

}
